<?php

// Set environment variables for development
if (php_sapi_name() === 'cli' || defined('STDIN')) {
    putenv('NODE_ENV=development');
}

// Set environment variables for packaged version
if (defined('PHP_BINARY') && PHP_BINARY) {
    putenv('PACKAGED=true');
    
    // Determine the package type based on PHP_BINARY
    if (strpos(PHP_BINARY, 'innosetup') !== false) {
        putenv('PACKAGE_TYPE=innosetup');
    } elseif (strpos(PHP_BINARY, 'your-nix-packager') !== false) {
        putenv('PACKAGE_TYPE=nix');
    } elseif (strpos(PHP_BINARY, 'macosx-packager') !== false) {
        putenv('PACKAGE_TYPE=macosx');
    }
}

// Rest of your PHP code goes here
?>
