<?php
/*

s:2256:"
Found in: /Users/johntebrown/Desktop/Github/Nexus-Final/php-app-server/www/ide/ICEcoder/data/logs/error/error.log...
[27-Oct-2023 17:55:48 UTC] PHP Warning:  Trying to access array offset on value of type null in /Users/johntebrown/Desktop/Github/Nexus-Final/php-app-server/www/ide/ICEcoder/lib/settings.php on line 49
[27-Oct-2023 17:55:48 UTC] PHP Warning:  Undefined variable $ICEcoder in /Users/johntebrown/Desktop/Github/Nexus-Final/php-app-server/www/ide/ICEcoder/lib/settings.php on line 108
[27-Oct-2023 17:55:48 UTC] PHP Warning:  Trying to access array offset on value of type null in /Users/johntebrown/Desktop/Github/Nexus-Final/php-app-server/www/ide/ICEcoder/lib/settings.php on line 108
[27-Oct-2023 17:55:48 UTC] PHP Deprecated:  Creation of dynamic property ICEcoder\Settings::$versionNo is deprecated in /Users/johntebrown/Desktop/Github/Nexus-Final/php-app-server/www/ide/ICEcoder/classes/Settings.php on line 11
[27-Oct-2023 17:55:48 UTC] PHP Deprecated:  Creation of dynamic property ICEcoder\Settings::$docRoot is deprecated in /Users/johntebrown/Desktop/Github/Nexus-Final/php-app-server/www/ide/ICEcoder/classes/Settings.php on line 12
[27-Oct-2023 17:55:48 UTC] PHP Deprecated:  Creation of dynamic property ICEcoder\Settings::$assetsRoot is deprecated in /Users/johntebrown/Desktop/Github/Nexus-Final/php-app-server/www/ide/ICEcoder/classes/Settings.php on line 13
[27-Oct-2023 17:55:48 UTC] PHP Deprecated:  Creation of dynamic property ICEcoder\Settings::$versionNo is deprecated in /Users/johntebrown/Desktop/Github/Nexus-Final/php-app-server/www/ide/ICEcoder/classes/Settings.php on line 11
[27-Oct-2023 17:55:48 UTC] PHP Deprecated:  Creation of dynamic property ICEcoder\Settings::$docRoot is deprecated in /Users/johntebrown/Desktop/Github/Nexus-Final/php-app-server/www/ide/ICEcoder/classes/Settings.php on line 12
[27-Oct-2023 17:55:48 UTC] PHP Deprecated:  Creation of dynamic property ICEcoder\Settings::$assetsRoot is deprecated in /Users/johntebrown/Desktop/Github/Nexus-Final/php-app-server/www/ide/ICEcoder/classes/Settings.php on line 13
[27-Oct-2023 17:55:48 UTC] PHP Warning:  Undefined array key "csrf" in /Users/johntebrown/Desktop/Github/Nexus-Final/php-app-server/www/ide/ICEcoder/lib/headers.php on line 21";

*/
?>