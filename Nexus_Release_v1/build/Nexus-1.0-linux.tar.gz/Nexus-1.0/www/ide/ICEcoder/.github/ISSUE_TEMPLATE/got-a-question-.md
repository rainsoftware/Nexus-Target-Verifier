---
name: Got a question?
about: Not sure about something, ask away!
title: ''
labels: Question
assignees: ''

---

**I'm not sure about...**
Explain what you're unsure about here. The more info the better if it's a complicated. Other people might have the same questions and can learn from replies, ask away!

**Describe where you're unsure**
Explain where you're at and what in ICEcoder is causing you issues, we can probably advise!

**Additional context**
Add any other context or screenshots about the question here.
