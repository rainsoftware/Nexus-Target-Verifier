document.addEventListener('DOMContentLoaded', function () {
  const contextMenu = document.getElementById('context-menu');

  document.addEventListener('contextmenu', function (event) {
    event.preventDefault();

    const x = event.pageX;
    const y = event.pageY;

    contextMenu.style.left = `${x}px`;
    contextMenu.style.top = `${y}px`;
    contextMenu.style.display = 'block';
  });

  document.addEventListener('click', function () {
    contextMenu.style.display = 'none';
  });


  contextMenu.addEventListener('click', function (event) {
    const menuItem = event.target.closest('sl-menu-item');

    if (menuItem) {
      const url = menuItem.dataset.url;
      if (url) {
        window.location.href = url;
      }
    }

    // Hide the context menu after clicking a menu item
    contextMenu.style.display = 'none';
  });
});
