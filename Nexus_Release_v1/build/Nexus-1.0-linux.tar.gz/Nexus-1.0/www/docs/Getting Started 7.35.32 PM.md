# getting started 
---
this file is defunc basically can only be found using the file manager.

this file is defunc only because the app is packaged and sourcecode does not contain the dos directly nor is it public, so congrats for finding whats basically a easter egg

the docs folder will likely be removed in future versions of Nexus.